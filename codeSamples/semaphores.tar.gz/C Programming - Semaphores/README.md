Filename: semaphores.c
Objective: Create multiple child threads that each print individual word. The objective of this program is to prove thread concurrency.

Usage: 

~/Desktop/C Programming - Semaphores> make && ./semaphors 10
cc -g -Wall   -c -o semaphors.o semaphors.c
cc -g -Wall   -c -o semProcs.o semProcs.c
gcc -o semaphors semaphors.o semProcs.o -g -Wall -lpthread
Tick tock the mouse ran up the clock
Tick tock the mouse ran up the clock
Tick tock the mouse ran up the clock
Tick tock the mouse ran up the clock
Tick tock the mouse ran up the clock
Tick tock the mouse ran up the clock
Tick tock the mouse ran up the clock
Tick tock the mouse ran up the clock
Tick tock the mouse ran up the clock
Tick tock the mouse ran up the clock

Parent done

