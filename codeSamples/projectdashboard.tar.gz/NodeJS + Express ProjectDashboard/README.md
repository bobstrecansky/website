Filename: api.js
Objective: Create a REST based JSON API to respond to HTTP web requests
Installation: Install nodejs (sudo apt-get install nodejs)
Usage: 

~/Desktop/NodeJS + Express ProjectDashboard> nodejs api.js
Magic happens on http://172.17.121.14:7164

