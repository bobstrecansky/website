#!/usr/bin/env python

"""
Test an Akamai configuration.

Not intended to be especially generic or reusable.
"""

from __future__ import division, print_function

import argparse
import collections
import csv
import functools
import re
import socket
import sys
import time
from multiprocessing import Pool

import requests


# Configuration stuff
COOKIES = ({}, {'beta': 'new'}, {'legacy': 'old'})
COOKIE_NAMES = {name for d in COOKIES for name in d}

DEFAULT_HEADERS = {
    'Pragma': 'akamai-x-cache-on, akamai-x-cache-remote-on, akamai-x-check-cacheable, akamai-x-get-cache-key, akamai-x-get-extracted-values, akamai-x-get-nonces, akamai-x-get-ssl-client-session-id, akamai-x-get-true-cache-key, akamai-x-serial-no',  # noqa
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.77 Safari/537.36',  # noqa
}

# List of (in-test?, path) pairs
PATHS = [
    (True, "/html/solutions/index.html"),
    (True, "/html/technology/index.html"),
    (True, "/html/industry/index.html"),
]

# Definition of a diagnostic request
Request = collections.namedtuple(
    'Request', ['address', 'host', 'path', 'headers', 'cookies', 'in_test'])


# Outcome of a diagnostic request
Result = collections.namedtuple('Result', ['address',
                                           'host',
                                           'path',
                                           'sent_cookies',
                                           'status_code',
                                           'origin',
                                           'received_cookies',
                                           'content_length',
                                           'in_test',
                                           'akamai_host',
                                           'cache_hit',
                                           'cache_key',
                                           'true_cache_key',
                                           'cacheable'])


# Return a generator of requests to send. See process_request
def generate_requests(paths, host, addresses=None, tests_per_path=1):
    headers = DEFAULT_HEADERS.copy()
    headers['Host'] = host
    for _ in xrange(tests_per_path):
        for in_test, path in paths:
            for cookies in COOKIES:
                for address in (addresses or [None]):
                    yield Request(address=address, host=host, path=path, headers=headers,
                                  cookies=cookies, in_test=in_test)


# Return sorted list of cookie pairs, ignoring those not in COOKIE_NAMES
def hashable_cookies(d):
    return tuple(sorted((k, v) for k, v in d.items() if k in COOKIE_NAMES))


# Return "new" or "old" to indicate which origin generated a response
def guess_origin(rsp):
    return 'new' if "Current revision:" in rsp.text else 'old'


# Parse the Akamai X-Cache header, returning (result, host)
def parse_x_cache(s):
    m = re.match(r"(\w+) from ([\w-]+)", s)
    return m.groups() if m else (None, None)


# Consume a Request and return a Result
def process_request(r, timeout=None, delay=0):
    address = r.address or r.host
    url = "http://%s%s" % (address, r.path)
    time.sleep(delay / 1000)
    before = time.time()
    try:
        rsp = requests.get(url, headers=r.headers, cookies=r.cookies, timeout=timeout)
    except (requests.exceptions.RequestException, socket.timeout) as e:
        elapsed = time.time() - before
        print("ERROR: " + str(e))
        result = Result(address=r.address, host=r.host, path=r.path,
                        sent_cookies=hashable_cookies(r.cookies),
                        status_code="timeout", origin=None,
                        received_cookies=None, content_length=0,
                        in_test=r.in_test, akamai_host=None,
                        cache_hit=None, cache_key=None,
                        true_cache_key=None, cacheable=None)
        return result, elapsed
    elapsed = time.time() - before
    print("%s [%.2f]" % (url, elapsed))
    cache_hit, akamai_host = parse_x_cache(rsp.headers.get('X-Cache', ''))
    cache_key = rsp.headers.get('X-Cache-Key')
    true_cache_key = rsp.headers.get('X-True-Cache-Key')
    cacheable = rsp.headers.get('X-Check-Cacheable')
    result = Result(address=r.address, host=r.host, path=r.path,
                    sent_cookies=hashable_cookies(r.cookies),
                    status_code=rsp.status_code,
                    origin=guess_origin(rsp),
                    received_cookies=hashable_cookies(rsp.cookies),
                    content_length=len(rsp.text), in_test=r.in_test,
                    akamai_host=akamai_host, cache_hit=cache_hit,
                    cache_key=cache_key, true_cache_key=true_cache_key,
                    cacheable=cacheable)
    return result, elapsed


# Return a pithy string describing goodness of the result
def analyze_result(result):
    # We always expect a successful http response
    if result.status_code != 200:
        return str(result.status_code)

    # Empty responses are always bad
    if result.content_length == 0:
        return "empty response"


    sent_cookies = dict(result.sent_cookies)
    received_cookies = dict(result.received_cookies)
'''
    # If this path isn't in the a/b test, expect old origin
    if not result.in_test:
        if result.origin != 'old':
            return "wrong origin (expected old)"
    # We sent the new-origin cookie, so expect new origin
    elif 'wp_helios_rollout' in sent_cookies:
        if result.origin != 'new':
            return "wrong origin (expected new)"
    # We sent the old-origin cookie, so expect old origin
    elif 'legacy_origin' in sent_cookies:
        if result.origin != 'old':
            return "wrong origin (expected old)"
    # We did not send either cookie; check for new-origin cookie
    elif 'wp_helios_rollout' in received_cookies:
        if result.origin != 'new':
            return "wrong origin (expected new)"
    # Check for old-origin cookie
    elif 'legacy_origin' in received_cookies:
        if result.origin != 'old':
            return "wrong origin (expected old)"
    # We didn't send or get a cookie, which is an error
    else:
        return "did not receive expected cookie"

    # If we sent a cookie and received one too, that's an error
    if sent_cookies and received_cookies:
        return "received unexpected cookies"
    # If we got this far, the response was correct
    return "ok"
'''

def main():
    # Parse arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', required=True, help="site hostname")
    parser.add_argument('--outputfile', '-o', required=True, help="write results to this file")
    parser.add_argument('--ntests', '-n', default=1, type=int, help="# of requests per path")
    parser.add_argument('--timeout', '-t', default=30, type=float, help="timeout (seconds)")
    parser.add_argument('--delay', '-d', default=0, type=float, help="wait between requests (ms)")
    parser.add_argument('--processes', '-p', default=32, type=int, help="# of parallel processes")
    parser.add_argument('--addresses', '-a', nargs='+', help="addresses to use instead of DNS")
    args = parser.parse_args()

    # Request the urls in parallel
    pool = Pool(args.processes)
    try:
        results = pool.map(functools.partial(process_request, timeout=args.timeout,
                                             delay=args.delay),
                           generate_requests(paths=PATHS, host=args.host,
                                             addresses=args.addresses,
                                             tests_per_path=args.ntests))
    except KeyboardInterrupt:
        pool.terminate()
        sys.exit(1)

    # Group results by everything, and count
    groupby = collections.defaultdict(lambda: [0, 0.0, None])
    for result, elapsed in results:
        groupby[result][0] += 1
        groupby[result][1] += elapsed

    # Apply some heuristics to analyze each result
    for result, info in sorted(groupby.iteritems()):
        info[2] = analyze_result(result)

    # Write the results as csv to our destination fil
    with open(args.outputfile, 'wb') as fp:
        writer = csv.writer(fp, quoting=csv.QUOTE_ALL)
        for result, (count, elapsed, outcome) in sorted(groupby.iteritems()):
            row = list(result)
            row.append(count)
            row.append(elapsed / count)
            row.append(outcome)
            writer.writerow(row)

    # Print an abbreviated summary
    total_requests, error_requests = 0, 0
    cache_misses = 0
    for result, (n, _, outcome) in groupby.iteritems():
        total_requests += n
        if outcome != "ok":
            error_requests += n
        if result.cache_hit == "TCP_MISS":
            cache_misses += n
    error_rate = error_requests / total_requests
    cache_hit_ratio = 1 - cache_misses / total_requests
    #print("\nErrors: %d of %d requests (%0.1f%%)" % (
    #    error_requests, total_requests, 100*error_rate))
    #print("Cache hit ratio: %0.2f" % (cache_hit_ratio,))


if __name__ == '__main__':
    main()

