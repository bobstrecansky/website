Filename: betaTest.py
Objective: Test against both a beta and a legacy origin
Installation Instructions: Install python software (sudo apt-get install python)
Execution: python betaTest.py --host www.akamai.com --outputfile results.txt

~/Desktop/Python - Beta Test Cookie> python betaTest.py --host www.akamai.com --outputfile results.txt
http://www.akamai.com/html/technology/index.html [0.29]
http://www.akamai.com/html/solutions/index.html [0.30]
http://www.akamai.com/html/technology/index.html [0.33]
http://www.akamai.com/html/solutions/index.html [0.35]
http://www.akamai.com/html/industry/index.html [0.38]
http://www.akamai.com/html/industry/index.html [0.38]
http://www.akamai.com/html/solutions/index.html [0.41]
http://www.akamai.com/html/technology/index.html [0.45]
http://www.akamai.com/html/industry/index.html [0.46]	
