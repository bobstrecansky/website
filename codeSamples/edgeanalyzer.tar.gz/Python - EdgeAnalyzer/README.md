Filename: EdgeAnalyzer.py
Objective: Test both Edge and Origin Best Practices
Installation Instructions: Install python software (sudo apt-get install python && sudo pip install timedelta tldextract)
Execution: 

python EdgeAnalyzer.py [cookies.txt file] [testHostname]"
Instructions to retrieve cookies.txt file:
1) Download the cookie exporter for firefox:"https://addons.mozilla.org/en-US/firefox/addon/cookie-exporter/"
2) Log into the Akamai control portal
3) Save the cookies.txt file to your computer  (Tools -> Export Cookies in Firefox)

