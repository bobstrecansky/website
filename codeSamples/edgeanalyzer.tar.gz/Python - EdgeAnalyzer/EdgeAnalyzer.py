#!/usr/bin/env python
# sudo pip install timedelta tldextract
import subprocess, os, re, sys, time, Tkinter, tkFileDialog, csv
#import tldextract
from datetime import date, timedelta
from sys import argv

if len(argv) == 3:
	scriptName, cookiesTxt, testHostname = argv
else:
	print ""
	print "Usage: python EdgeAnalyzer.py [cookies.txt file] [testHostname]"
	print ""
	print "####################################################################"
	print "Instructions to retrieve cookies.txt file:"
	print "1) Download the cookie exporter for firefox:"
	print "   https://addons.mozilla.org/en-US/firefox/addon/cookie-exporter/"
	print "2) Log into the portal"
	print "3) Change the context to the customer you want to report for"
	print "4) Save the cookies.txt file to your computer"
	print "   (Tools -> Export Cookies in Firefox)"
	print "####################################################################"
	print ""
	exit()

#Check the hostname is valid
def is_valid_hostname(hostname):
    if len(hostname) > 255:
        return False
    if hostname[-1] == ".":
        hostname = hostname[:-1] # strip exactly one dot from the right, if present
    allowed = re.compile("(?!-)[A-Z\d-]{1,63}(?<!-)$", re.IGNORECASE)
    return all(allowed.match(x) for x in hostname.split("."))

checkHost = is_valid_hostname(testHostname);
print checkHost

if testHostname.count('.') < 2:
	print "please do not use top level domains"
	exit()

if checkHost:
	print "Valid hostname"
else:
	print "Not a valid hostname" 
	exit()

#Pull Top Level Domain Name from input hostname
domainName = testHostname.partition('.')[2]
print domainName

#Retrieve CP code from the hostname 
curlInput = "curl -Is -H 'Pragma:akamai-x-get-cache-key'" + " " + testHostname + " " + "| grep X-Cache-Key: | cut -d '/' -f 4 | sed 's/[^0-9]//g'"
proc = subprocess.Popen([curlInput], stdout=subprocess.PIPE, shell=True)
(CPCode, err) = proc.communicate()
stripNew = CPCode.rstrip('\n')

#Copy the configuration file to a local stream (arlparsed.txt has all of the parsed output files, gets generated on request):
retrieveXML = "grep -iE '^" +testHostname+ " ' arlparsed.txt"" | awk '{print $2;}'"
print retrieveXML
proc = subprocess.Popen([retrieveXML], stdout=subprocess.PIPE, shell=True)
(fileName, err) = proc.communicate()

print fileName

copyFile = "cp /usr/local/akamai/tools/metadata/arl.data/"+fileName+ " ."
print copyFile

proc = subprocess.Popen([copyFile], stdout=subprocess.PIPE, shell=True)
(copiedFile, err) = proc.communicate()


#Parse All CP Codes from ARL.data:
totalCpCodes = "find /usr/local/akamai/tools/metadata/arl.data/ -name " + "*" + domainName + "*"" | xargs cat | grep reporting:cp | sed -e 's/<[^>]*>//g' | sed -e 's/^[ \t]*//'"
proc = subprocess.Popen([totalCpCodes], stdout=subprocess.PIPE, shell=True)
(allCpCodes, err) = proc.communicate()
allCpCodesFormatted = allCpCodes.rstrip(' ')

#Retrieve Edge Hostname from the Hostname 
edgeInput = "dig " + testHostname + " +short | grep -iE '(edgesuite|edgekey|akadns)'" 
proc = subprocess.Popen([edgeInput], stdout=subprocess.PIPE, shell=True)
(edgeHostname, err) = proc.communicate()

#Retrieve Mapname from the Hostname 
mapInput = "dig " + testHostname + " +short | sed -n 2p" 
proc = subprocess.Popen([mapInput], stdout=subprocess.PIPE, shell=True)
(mapName, err) = proc.communicate()

#Find TTL for Hostname
findTtl = "dig -t CNAME +noall +answer +ttlid " + testHostname + " | awk '{print $2}'" 
proc = subprocess.Popen([findTtl], stdout=subprocess.PIPE, shell=True)
(ttlOut, err) = proc.communicate()

if ttlOut < 3600:
	ttlOutConform = "No"
	ttlPractice = "TTLs Should be set for longer then an hour"
else:
	ttlOutConform = "Yes"
	ttlPractice = "TTL is set for longer then an hour"

#Find Origin Hostnames
originHostnames = "find /usr/local/akamai/tools/metadata/arl.data/ -name " + "*" + testHostname + "*"" | xargs cat | grep 'forward:origin-server.host' | sed -e 's/<[^>]*>//g' | sed -e 's/^[ \t]*//' | sort -u"
proc = subprocess.Popen([originHostnames], stdout=subprocess.PIPE, shell=True)
(originNames, err) = proc.communicate()
#print "Origin Names: " +originNames

#Retrieve Main Origin Name For Parsing
originName = "find /usr/local/akamai/tools/metadata/arl.data/ -name " + "*" + testHostname + "*"" | xargs cat | grep forward:origin | head -1 | sed -e 's/<[^>]*>//g' | sed -e 's/^[ \t]*//'"
proc = subprocess.Popen([originName], stdout=subprocess.PIPE, shell=True)
(mainOriginName, err) = proc.communicate()
originOut = mainOriginName.rstrip('\n')

#print "Main Origin Name: " +mainOriginName

headerOut = "curl -Is " +originOut +" -H 'host:" +testHostname +"' -o originHeaders.txt" 
proc = subprocess.Popen([headerOut], stdout=subprocess.PIPE, shell=True)
(mainHeaderOut, err) = proc.communicate()

##### DEBUG SECTION #####

print "stripNew: " +stripNew
print "allCpCodesFormatted: " +allCpCodesFormatted
print "edgeHostname: " +edgeHostname
print "mapName: " +mapName
print "ttlOut: " +ttlOut
print "Origin Names: " +originNames
print "Main Origin Name: " +originOut
print "Main headerOut: "+ mainHeaderOut

####################
#iON Compliance    
####################

# Enahanced Akamai Protocol: search for "Enable dupack support" (Configuration Manager) or "EAP is enabled" (Property Manager)  in Metadata 
# Akamai Instant: search for "rel-attribute-values" in Metadata
# Map Rules: search for an "a" in an edgekey hostname or a "r" in a edgesuite hostname


####################
#Origin Checks#
####################

# Last Modified
lastModified = "curl -Is " +originOut +" -H 'host:" +testHostname +"' | grep -iE 'last-modified'" 
proc = subprocess.Popen([lastModified], stdout=subprocess.PIPE, shell=True)
(lastModifiedOut, err) = proc.communicate()
if "last-modified" in lastModifiedOut:
	lastModifiedConform = "Yes"
	lastModifiedPractice = "The origin header contains a last modified date"
else:
	lastModifiedConform = "No" 
	lastModifiedPractice = "The origin header does not contain a last modified date"

# Gzip
gzip = "curl -Is " +originOut +" -H 'host:" +testHostname +"' | grep -iE 'accept-encoding'" 
proc = subprocess.Popen([gzip], stdout=subprocess.PIPE, shell=True)
(gzipOut, err) = proc.communicate()
if "accept-encoding: gzip" in lastModifiedOut:
	gzipConform = "Yes"
	gzipPractice = "The origin accepts gzip encoding"
else:
	gzipConform = "No" 
	gzipPractice = "The origin does not accept gzip encoding"

# Mime Type
contentType = "curl -Is " +originOut +" -H 'host:" +testHostname +"' | grep -iE 'Content-Type'" 
proc = subprocess.Popen([contentType], stdout=subprocess.PIPE, shell=True)
(contentTypeOut, err) = proc.communicate()
if "Content-Type" in contentTypeOut:
	contentTypeConform = "Yes"
	contentTypePractice = "The origin does produce a content type"
else:
	contentTypeConform = "No" 
	contentTypePractice = "The origin does not produce a content type"

# Vary Header
vary = "curl -Is " +originOut +" -H 'host:" +testHostname +"' | grep -iE 'vary'" 
proc = subprocess.Popen([vary], stdout=subprocess.PIPE, shell=True)
(varyOut, err) = proc.communicate()
if "vary" in contentTypeOut:
	varyConform = "No"
	varyPractice = "The origin produces a vary header"
else:
	varyConform = "Yes" 
	varyPractice = "The origin does not produce a vary header"

# Content Length
contentLength = "curl -Is " +originOut +" -H 'host:" +testHostname +"' | grep -iE 'Content-Length'" 
proc = subprocess.Popen([contentLength], stdout=subprocess.PIPE, shell=True)
(contentLengthOut, err) = proc.communicate()
if "Content-Length" in contentTypeOut:
	contentLengthConform = "Yes"
	contentLengthPractice = "The origin produces a content length"
else:
	contentLengthConform = "No" 
	contentLengthPractice = "The origin does not produce a content length"

#print "last modified: " +lastModifiedConform +lastModifiedPractice
#print "gzip: " +gzipConform +gzipPractice
#print "mime: " +contentTypeConform +contentTypePractice
#print "vary: " +varyConform +varyPractice
#print "content: " +contentLengthConform +contentLengthPractice


# Get todays date and 2 days ago date
today = (time.strftime("%Y%m%d"))
yesterday = num = re.sub(r'\D', "", str(date.today()-timedelta(days=2)))
#print "today: " +today

#Core reports found here: https://agora.akamai.com/wiki/Portal_Core_Reports
csvUrl = "https://control.akamai.com/core-reports/services/urls/top/hits/cpcode/{0}/ui/export.csv?start_date={1}&end_date={2}&start_time=0000&end_time=1240&traffic_option=all&ipversion=all&max_points=870&time_zone=EST&locale=en_US".format(stripNew,yesterday,today)
#print csvUrl

#Retrieve the log files for the given CP Code
getData = "curl -L -sk -b " + cookiesTxt + " -o output.csv " + "\"" + csvUrl + "\"" 
#print "GETDATA:" +getData
proc = subprocess.Popen([getData], stdout=subprocess.PIPE, shell=True)
(jsonOut, err) = proc.communicate()

#Group urls to cURL
parseURLs = "cat output.csv | grep .com | tail -10 | cut -d ',' -f 1 | sed 's/origin-//g' > urls.txt"
proc = subprocess.Popen([parseURLs], stdout=subprocess.PIPE, shell=True)
(urlsToCurl, err) = proc.communicate()

findCacheable = "cat urls.txt | xargs curl -Is -H 'pragma:akamai-x-get-cache-key'| grep X-Cache-Key | cut -d '/' -f 5 > checkCacheable.txt"
proc = subprocess.Popen([findCacheable], stdout=subprocess.PIPE, shell=True)
(CacheableUrls, err) = proc.communicate()

with open("urls.txt", "r") as urlFile:
    topUrls = urlFile.read().splitlines()

with open("checkCacheable.txt", "r") as cacheableFile:
    isCacheable = cacheableFile.read().splitlines()

cacheNotice = []

for x in xrange(0,10):
	if isCacheable[x] == "000":
		cacheNotice.append("NO")
	else:	
		cacheNotice.append('YES')

result = zip(topUrls, isCacheable, cacheNotice)
#for i, a in enumerate(result):
#	print i, a


for row in result:
	tempOut = row
#	print tempOut

f = open('CustomerOutput.csv', 'wb')
fileWriter = csv.writer(f)
for row in result:
    tempRow = row
    fileWriter.writerow(tempRow)

#findCacheable = "cat CustomerOutput.csv"
#proc = subprocess.Popen([findCacheable], stdout=subprocess.PIPE, shell=True)
#(topTenUrls, err) = proc.communicate()


#HTML Formatting


print """
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<style>
	.CSSTableGenerator {
	margin:0px;padding:0px;
	width:100%;
	box-shadow: 10px 10px 5px #888888;
	border:1px solid #0000bf;
	
	-moz-border-radius-bottomleft:0px;
	-webkit-border-bottom-left-radius:0px;
	border-bottom-left-radius:0px;
	
	-moz-border-radius-bottomright:0px;
	-webkit-border-bottom-right-radius:0px;
	border-bottom-right-radius:0px;
	
	-moz-border-radius-topright:0px;
	-webkit-border-top-right-radius:0px;
	border-top-right-radius:0px;
	
	-moz-border-radius-topleft:0px;
	-webkit-border-top-left-radius:0px;
	border-top-left-radius:0px;
}.CSSTableGenerator table{
    border-collapse: collapse;
        border-spacing: 0;
	width:100%;
	height:100%;
	margin:0px;padding:0px;
}.CSSTableGenerator tr:last-child td:last-child {
	-moz-border-radius-bottomright:0px;
	-webkit-border-bottom-right-radius:0px;
	border-bottom-right-radius:0px;
}
.CSSTableGenerator table tr:first-child td:first-child {
	-moz-border-radius-topleft:0px;
	-webkit-border-top-left-radius:0px;
	border-top-left-radius:0px;
}
.CSSTableGenerator table tr:first-child td:last-child {
	-moz-border-radius-topright:0px;
	-webkit-border-top-right-radius:0px;
	border-top-right-radius:0px;
}.CSSTableGenerator tr:last-child td:first-child{
	-moz-border-radius-bottomleft:0px;
	-webkit-border-bottom-left-radius:0px;
	border-bottom-left-radius:0px;
}.CSSTableGenerator tr:hover td{
	
}
.CSSTableGenerator tr:nth-child(odd){ background-color:#ffaa56; }
.CSSTableGenerator tr:nth-child(even)    { background-color:#ffffff; }.CSSTableGenerator td{
	vertical-align:middle;
	
	
	border:1px solid #0000bf;
	border-width:0px 1px 1px 0px;
	text-align:left;
	padding:7px;
	font-size:10px;
	font-family:Arial;
	font-weight:bold;
	color:#000000;
}.CSSTableGenerator tr:last-child td{
	border-width:0px 1px 0px 0px;
}.CSSTableGenerator tr td:last-child{
	border-width:0px 0px 1px 0px;
}.CSSTableGenerator tr:last-child td:last-child{
	border-width:0px 0px 0px 0px;
}
.CSSTableGenerator tr:first-child td{
		background:-o-linear-gradient(bottom, #ff7f00 5%, #bf5f00 100%);	background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #ff7f00), color-stop(1, #bf5f00) );
	background:-moz-linear-gradient( center top, #ff7f00 5%, #bf5f00 100% );
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#ff7f00", endColorstr="#bf5f00");	background: -o-linear-gradient(top,#ff7f00,bf5f00);

	background-color:#ff7f00;
	border:0px solid #0000bf;
	text-align:center;
	border-width:0px 0px 1px 1px;
	font-size:14px;
	font-family:Arial;
	font-weight:bold;
	color:#ffffff;
}
.CSSTableGenerator tr:first-child:hover td{
	background:-o-linear-gradient(bottom, #ff7f00 5%, #bf5f00 100%);	background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #ff7f00), color-stop(1, #bf5f00) );
	background:-moz-linear-gradient( center top, #ff7f00 5%, #bf5f00 100% );
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#ff7f00", endColorstr="#bf5f00");	background: -o-linear-gradient(top,#ff7f00,bf5f00);

	background-color:#ff7f00;
}
.CSSTableGenerator tr:first-child td:first-child{
	border-width:0px 0px 1px 0px;
}
.CSSTableGenerator tr:first-child td:last-child{
	border-width:0px 0px 1px 1px;
}

</style>
</head>

<h1>Edge Analyzer Results</h1><h3>Edge:</h3>
<div class="CSSTableGenerator">
<table>
<tr><td>Attribute</td><td>Value</td>
"""

#Main CP Code
print "<tr><td>Main CP Code</td><td>"
print stripNew
print "</td></tr>"

#All CP Codes
print "<tr><td>All CP Codes</td><td>"
print allCpCodesFormatted
print "</td></tr>"

#Map Name
print "<tr><td>Map Name</td><td>"
print mapName
print "</td></tr>"

#Edge Hostname
print "<tr><td>Edge Hostname</td><td>"
print edgeHostname
print "</td></tr>"

print "<tr><td>Origin Hostnames</td><td>"
print originNames
print "</td></tr></table></div>"

#ORIGIN CONFIG
print """<br><br><br>
<h3>Origin:</h3>
<div class="CSSTableGenerator">
<table>
<tr><td>Attribute</td><td>Conforms to Best Practice</td><td>Notes</td>
"""



#print "last modified: " +lastModifiedConform +lastModifiedPractice
#print "gzip: " +gzipConform +gzipPractice
#print "mime: " +contentTypeConform +contentTypePractice
#print "vary: " +varyConform +varyPractice
#print "content: " +contentLengthConform +contentLengthPractice



print "<tr><td>DNS TTL</td><td>"+ttlOutConform +"</td><td>"+ttlPractice+"</td>"
print "<tr><td>Last Modified Date Enabled</td><td>"+lastModifiedConform +"</td><td>"+lastModifiedPractice+"</td>"
print "<tr><td>Gzip Content</td><td>"+gzipConform +"</td><td>"+gzipPractice+"</td>"
print "<tr><td>Mime Type</td><td>"+contentTypeConform +"</td><td>"+contentTypePractice+"</td>"
print "<tr><td>Vary</td><td>"+varyConform +"</td><td>"+varyPractice+"</td>"
print "<tr><td>Content Length</td><td>"+contentLengthConform +"</td><td>"+contentLengthPractice+"</td>"
print"</tr></table></div>"

print "<br><br><br>"

print "<h3>Top URLs and Cacheability:</h3>"
print """<div class="CSSTableGenerator">
<table>
<tr><td>URL</td><td>TTL</td><td>Is Cacheable</td></tr>
"""

for i in range(len(result)):
	print "<tr><td>" +topUrls[i] +"</td><td>" +isCacheable[i] + "</td><td>" +cacheNotice[i] + "</td>"
print """
</tr>
</table>
</div>
<br>
</html>
"""

