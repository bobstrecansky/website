Filename: createDB.sql
Objective: Postgresql database creation
Installation Instructions: Install ocaml software (sudo apt-get install postgresql)
Execution: change user to postgres (sudo su - postgres) and execute script (psql -f createDB.sql).

	
